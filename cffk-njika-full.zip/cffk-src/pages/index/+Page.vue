<template>
  <div class="nj-page">
    <StorefrontHeader />

    <!-- Hero -->
    <section id="notice" class="nj-hero">
      <div class="nj-hero-inner">
        <div class="nj-hero-left">
          <div class="nj-eyebrow">DIGITAL SERVICES</div>
          <h1 class="nj-h1">{{ site.name }} <span>AI 服务一站直达</span></h1>
          <p class="nj-sub">{{ site.subtitle || "数字商品自动发货·付款后凭证即时送达" }}</p>
          <p v-if="site.notice" class="nj-notice">{{ site.notice }}</p>
        </div>
        <div class="nj-hero-right">
          <div class="nj-search">
            <SearchIcon />
            <input v-model="query" :placeholder="messages.storefront.searchProducts" aria-label="搜索商品" />
          </div>
          <button type="button" class="nj-share" @click="shareSite">
            <Share2Icon /><span>分享本站</span>
          </button>
        </div>
      </div>
    </section>

    <!-- Featured -->
    <section v-if="featured.length" class="nj-sec">
      <div class="nj-eyebrow">FEATURED</div>
      <h2 class="nj-h2">为你精选</h2>
      <div class="nj-feat-grid">
        <article v-for="product in featured" :key="product.id" class="nj-feat-card">
          <a :href="`/product/${product.slug}`" class="nj-feat-link">
            <h3 class="nj-feat-title"><template v-for="(seg, i) in nameParts(product.name)" :key="i"><span :style="seg.c ? `color:${seg.c}` : ''">{{ seg.t }}</span></template></h3>
            <p v-if="product.subtitle" class="nj-feat-sub">{{ product.subtitle }}</p>
            <FeaturedBanner :product="product" />
            <div class="nj-feat-foot">
              <div class="nj-price"><b>¥{{ product.price }}</b><span>起</span></div>
              <span class="nj-cta">查看商品 ›</span>
            </div>
          </a>
        </article>
      </div>
    </section>

    <!-- Categories + products -->
    <section class="nj-sec">
      <div class="nj-eyebrow">CATEGORIES</div>
      <h2 class="nj-h2">商品分类</h2>
      <div class="nj-main">
        <aside class="nj-cats">
          <button type="button" class="nj-cat" :class="{ active: selectedCategory === null }" @click="selectedCategory = null">
            <span class="nj-cat-icon nj-cat-all"><SparklesIcon /></span>
            <span class="nj-cat-name">全部商品</span>
            <span class="nj-cat-count">{{ data.products.length }}</span>
          </button>
          <button
            v-for="cat in data.categories"
            :key="cat.id"
            type="button"
            class="nj-cat"
            :class="{ active: selectedCategory === cat.id }"
            @click="selectedCategory = cat.id"
          >
            <span class="nj-cat-icon">
              <img v-if="categoryIcon(cat)" :src="categoryIcon(cat)!" :alt="cat.name" />
              <LayoutGridIcon v-else />
            </span>
            <span class="nj-cat-name">{{ cat.name }}</span>
            <span class="nj-cat-count">{{ productCount(cat.id) }}</span>
          </button>
        </aside>

        <div class="nj-grid-wrap">
          <div v-if="visibleProducts.length" class="nj-grid">
            <article v-for="(product, idx) in visibleProducts" :key="product.id" class="nj-card">
              <span v-if="isOutOfStock(product)" class="nj-corner nj-corner-sold">售罄</span>
              <span v-else-if="idx === 0 && selectedCategory === null && !query" class="nj-corner nj-corner-hot">推荐</span>
              <a :href="`/product/${product.slug}`" class="nj-card-link">
                <div class="nj-picon">
                  <img :src="productVisual(product)" :alt="product.name" />
                </div>
                <h3 class="nj-pname">{{ product.name }}</h3>
                <div class="nj-tags">
                  <span v-if="isAutoDelivery(product)" class="nj-tag nj-tag-green">自动交付</span>
                  <span class="nj-tag nj-tag-blue">游客可购</span>
                </div>
                <div class="nj-pfoot">
                  <span class="nj-pprice-label">到手价</span>
                  <b class="nj-pprice">¥{{ product.price }}</b>
                  <span class="nj-stock" :class="stockClass(product)">{{ stockLabel(product) }}</span>
                </div>
              </a>
            </article>
          </div>
          <div v-else class="nj-empty">
            <PackageOpenIcon />
            <h3>{{ messages.storefront.noProducts }}</h3>
            <p>{{ messages.storefront.noProductsDescription }}</p>
          </div>
        </div>
      </div>
    </section>

    <StorefrontFooter />

    <a :href="supportHref" class="nj-float-service" :target="supportExternal ? '_blank' : undefined" rel="noopener noreferrer" aria-label="在线客服">
      <HeadphonesIcon /><span>在线客服</span>
    </a>
  </div>
</template>

<script lang="ts" setup>
import { computed, ref } from "vue";
import { HeadphonesIcon, LayoutGridIcon, PackageOpenIcon, SearchIcon, Share2Icon, SparklesIcon } from "@lucide/vue";
import { toast } from "vue-sonner";
import { useData } from "vike-vue/useData";
import { usePageContext } from "vike-vue/usePageContext";
import FeaturedBanner from "@/components/storefront/FeaturedBanner.vue";
import StorefrontFooter from "@/components/storefront/StorefrontFooter.vue";
import StorefrontHeader from "@/components/storefront/StorefrontHeader.vue";
import { pickBrandIcon } from "@/lib/category-icons";
import { useStorefrontPreferences } from "@/lib/storefront-preferences";
import type { Data } from "./+data.server";

type Product = Data["products"][number];
type Category = Data["categories"][number];
type Site = {
  name: string;
  subtitle: string | null;
  logo: string | null;
  notice: string | null;
  footerText: string | null;
  supportContact: string | null;
};

const data = useData<Data>();
const pageContext = usePageContext() as unknown as { site: Site };
const site = pageContext.site;
const { messages, t } = useStorefrontPreferences();
const selectedCategory = ref<number | null>(null);
const query = ref("");

const visibleProducts = computed(() => {
  const keyword = query.value.trim().toLowerCase();
  return data.products.filter((product) =>
    (selectedCategory.value === null || product.categoryId === selectedCategory.value)
    && (!keyword || product.name.toLowerCase().includes(keyword) || product.subtitle?.toLowerCase().includes(keyword)),
  );
});

const featured = computed(() => data.products.slice(0, 4));

function productCount(categoryId: number) {
  return data.products.filter((p) => p.categoryId === categoryId).length;
}

function categoryIcon(cat: Category): string | null {
  return pickBrandIcon(cat.name) ?? pickBrandIcon(cat.slug);
}

function productVisual(product: Product): string {
  if (product.coverImage) return product.coverImage;
  return pickBrandIcon(product.categoryName) ?? pickBrandIcon(product.name) ?? pickBrandIcon("tool") ?? "";
}

function isAutoDelivery(product: Product) {
  return product.deliveryType === "CARD_AUTO" || product.deliveryType === "FIXED_CARD" || product.deliveryType === "SUPPLIER";
}

function isOutOfStock(product: Product) {
  return product.availableStock !== null && product.availableStock <= 0;
}

function stockLabel(product: Product) {
  if (product.availableStock === null) return messages.value.storefront.stockAvailable;
  return product.availableStock > 0
    ? t(messages.value.storefront.stockCount, { count: product.availableStock })
    : messages.value.storefront.outOfStock;
}

function stockClass(product: Product) {
  if (product.availableStock === null || product.availableStock > 10) return "nj-stock-ok";
  if (product.availableStock === 0) return "nj-stock-out";
  return "nj-stock-low";
}

/** Split a product name into colored segments for the featured title. */
function nameParts(name: string): Array<{ t: string; c?: string }> {
  const rules: Array<[RegExp, string]> = [
    [/Plus/i, "#14b8a6"],
    [/\bPro\b/i, "#7c3aed"],
    [/(\d+\s*\/\s*\d+\s*个月|\d+\s*个月)/, "#7c3aed"],
    [/成品号/, "var(--nj-text)"],
    [/旗舰版|高级版/, "#ea580c"],
  ];
  for (const [re, color] of rules) {
    const m = name.match(re);
    if (m && m.index !== undefined) {
      const parts: Array<{ t: string; c?: string }> = [];
      if (m.index > 0) parts.push({ t: name.slice(0, m.index) });
      parts.push({ t: m[0], c: color });
      if (m.index + m[0].length < name.length) parts.push({ t: name.slice(m.index + m[0].length) });
      return parts;
    }
  }
  return [{ t: name }];
}

const supportHref = computed(() => {
  const first = (site.supportContact ?? "").split("\n").map((l) => l.trim()).find(Boolean) ?? "";
  if (!first) return "#";
  const address = first.includes("|") ? first.slice(first.indexOf("|") + 1).trim() : first;
  return address.includes(":") ? address : `mailto:${address}`;
});
const supportExternal = computed(() => supportHref.value.startsWith("http"));

async function shareSite() {
  const url = window.location.href;
  try {
    await navigator.clipboard.writeText(url);
    toast.success("链接已复制,分享给朋友吧");
  } catch {
    toast.error("复制失败,请手动复制地址栏链接");
  }
}
</script>

<style scoped>
.nj-page { background: var(--nj-bg); min-height: 100vh; }
/* hero */
.nj-hero { padding: 44px 0 10px; }
.nj-hero-inner {
  max-width: 1200px; margin: 0 auto; padding: 0 24px;
  display: flex; justify-content: space-between; align-items: flex-end; gap: 24px; flex-wrap: wrap;
}
.nj-eyebrow { font-size: 11px; font-weight: 700; letter-spacing: 3px; color: #14b8a6; margin-bottom: 10px; }
.nj-h1 { font-size: 42px; font-weight: 800; color: var(--nj-text); margin: 0; letter-spacing: 1px; }
.nj-h1 span { color: var(--nj-text-2); font-weight: 700; }
.nj-sub { color: var(--nj-muted); font-size: 14px; margin: 10px 0 0; }
.nj-notice {
  display: inline-block; margin-top: 12px; font-size: 13px; color: #0d9488;
  background: rgba(20, 184, 166, 0.1); border: 1px solid rgba(20, 184, 166, 0.25);
  padding: 8px 16px; border-radius: 999px;
}
.nj-hero-right { display: flex; gap: 12px; align-items: center; }
.nj-search {
  display: flex; align-items: center; gap: 10px; background: var(--nj-card);
  border: 1px solid var(--nj-input-border); border-radius: 14px; padding: 0 18px; height: 52px; width: 340px;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03);
}
.nj-search svg { width: 17px; height: 17px; color: var(--nj-muted); flex-shrink: 0; }
.nj-search input { border: 0; outline: 0; font-size: 14px; width: 100%; color: var(--nj-text); background: transparent; }
.nj-search input::placeholder { color: var(--nj-muted); }
.nj-share {
  display: flex; align-items: center; gap: 8px; height: 52px; padding: 0 22px;
  background: var(--nj-card); border: 1px solid var(--nj-input-border); border-radius: 14px;
  color: #14b8a6; font-size: 14px; font-weight: 600; cursor: pointer;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.03); transition: all 0.18s; white-space: nowrap;
}
.nj-share svg { width: 16px; height: 16px; }
.nj-share:hover { border-color: #14b8a6; transform: translateY(-1px); }
/* sections */
.nj-sec { max-width: 1200px; margin: 0 auto; padding: 34px 24px 0; }
.nj-h2 { font-size: 26px; font-weight: 800; color: var(--nj-text); margin: 0 0 20px; }
/* featured */
.nj-feat-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 22px; }
.nj-feat-card {
  background: var(--nj-card); border-radius: 22px; padding: 26px 0 24px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04); transition: all 0.22s; overflow: hidden; position: relative;
}
.nj-feat-card:hover { transform: translateY(-3px); box-shadow: 0 12px 32px rgba(0, 0, 0, 0.09); }
.nj-feat-link { text-decoration: none; display: block; }
.nj-feat-title { font-size: 21px; font-weight: 800; color: var(--nj-text); margin: 0; padding: 0 26px; }
.nj-feat-sub { font-size: 13px; color: var(--nj-muted); margin: 8px 0 0; padding: 0 26px; }
.nj-feat-foot { display: flex; justify-content: space-between; align-items: center; padding: 18px 26px 0; }
.nj-price b { font-size: 24px; font-weight: 800; color: var(--nj-text); }
.nj-price span { font-size: 13px; color: var(--nj-muted); margin-left: 4px; }
.nj-cta {
  background: linear-gradient(135deg, #14b8a6, #0d9488); color: #fff;
  font-size: 13.5px; font-weight: 600; padding: 11px 24px; border-radius: 999px;
  box-shadow: 0 4px 14px rgba(20, 184, 166, 0.35);
}
/* main: cats + grid */
.nj-main { display: grid; grid-template-columns: 240px 1fr; gap: 22px; align-items: start; }
.nj-cats {
  background: var(--nj-card); border-radius: 20px; padding: 14px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04);
  position: sticky; top: 84px; display: flex; flex-direction: column; gap: 4px;
}
.nj-cat {
  display: flex; align-items: center; gap: 12px; width: 100%;
  padding: 11px 12px; border: 0; border-radius: 14px; background: transparent;
  cursor: pointer; transition: all 0.16s; text-align: left;
}
.nj-cat:hover { background: var(--nj-bg); }
.nj-cat.active { background: rgba(20, 184, 166, 0.1); }
.nj-cat-icon {
  width: 38px; height: 38px; border-radius: 12px; background: var(--nj-bg); flex-shrink: 0;
  display: flex; align-items: center; justify-content: center; overflow: hidden;
}
.nj-cat-icon img { width: 100%; height: 100%; object-fit: cover; }
.nj-cat-icon svg { width: 18px; height: 18px; color: var(--nj-muted); }
.nj-cat-all { background: linear-gradient(135deg, #14b8a6, #0d9488); }
.nj-cat-all svg { color: #fff; }
.nj-cat.active .nj-cat-name { color: #0d9488; font-weight: 700; }
.nj-cat-name { font-size: 14px; color: var(--nj-text); flex: 1; }
.nj-cat-count {
  font-size: 11px; font-weight: 700; color: var(--nj-muted); background: var(--nj-bg);
  min-width: 24px; height: 22px; border-radius: 999px;
  display: flex; align-items: center; justify-content: center; padding: 0 7px;
}
.nj-cat.active .nj-cat-count { background: #14b8a6; color: #fff; }
/* product grid */
.nj-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 18px; }
.nj-card {
  background: var(--nj-card); border-radius: 20px; padding: 24px 20px 20px; position: relative;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04); transition: all 0.2s; overflow: hidden;
}
.nj-card:hover { transform: translateY(-3px); box-shadow: 0 12px 30px rgba(0, 0, 0, 0.09); }
.nj-corner {
  position: absolute; top: 0; right: 0; width: 64px; height: 64px; z-index: 2;
  font-size: 12px; font-weight: 700; color: #fff;
  display: flex; align-items: flex-start; justify-content: flex-end;
  padding: 10px 10px 0 0;
}
.nj-corner::before {
  content: ""; position: absolute; top: -32px; right: -32px; width: 64px; height: 64px;
  border-radius: 50%;
}
.nj-corner-hot::before { background: rgba(20, 184, 166, 0.16); }
.nj-corner-hot { color: #0d9488; }
.nj-corner-sold::before { background: rgba(239, 68, 68, 0.14); }
.nj-corner-sold { color: #ef4444; }
.nj-card-link { text-decoration: none; display: block; }
.nj-picon {
  width: 72px; height: 72px; border-radius: 18px; overflow: hidden; margin: 0 auto 14px;
  background: var(--nj-bg); box-shadow: 0 4px 12px rgba(0, 0, 0, 0.06);
}
.nj-picon img { width: 100%; height: 100%; object-fit: cover; }
.nj-pname { font-size: 15px; font-weight: 700; color: var(--nj-text); text-align: center; margin: 0 0 10px; line-height: 1.5; }
.nj-tags { display: flex; gap: 8px; justify-content: center; margin-bottom: 14px; }
.nj-tag { font-size: 11.5px; font-weight: 600; padding: 4px 12px; border-radius: 999px; }
.nj-tag-green { background: rgba(20, 184, 166, 0.12); color: #0d9488; }
.nj-tag-blue { background: rgba(59, 130, 246, 0.1); color: #2563eb; }
.nj-pfoot { display: flex; align-items: baseline; justify-content: center; gap: 6px; border-top: 1px solid var(--nj-border); padding-top: 14px; }
.nj-pprice-label { font-size: 12px; color: var(--nj-muted); }
.nj-pprice { font-size: 19px; font-weight: 800; color: var(--nj-text); }
.nj-stock { font-size: 12px; margin-left: 8px; }
.nj-stock-ok { color: #14b8a6; }
.nj-stock-low { color: #f59e0b; }
.nj-stock-out { color: #ef4444; }
.nj-empty {
  background: var(--nj-card); border-radius: 20px; padding: 70px 20px; text-align: center;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.04);
}
.nj-empty svg { width: 40px; height: 40px; color: var(--nj-muted); margin: 0 auto; }
.nj-empty h3 { font-size: 16px; color: var(--nj-text); margin: 14px 0 6px; }
.nj-empty p { font-size: 13px; color: var(--nj-muted); margin: 0; }
/* floating service */
.nj-float-service {
  position: fixed; right: 22px; top: 40%; z-index: 40;
  display: flex; flex-direction: column; align-items: center; gap: 6px;
  background: var(--nj-card); border: 1px solid var(--nj-border); border-radius: 16px; padding: 14px 10px;
  color: #0d9488; font-size: 12px; font-weight: 600; text-decoration: none;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.08); writing-mode: vertical-rl; letter-spacing: 2px;
}
.nj-float-service svg { width: 18px; height: 18px; writing-mode: horizontal-tb; }
.nj-float-service:hover { border-color: #14b8a6; }
@media (max-width: 1024px) {
  .nj-main { grid-template-columns: 1fr; }
  .nj-cats { position: static; flex-direction: row; overflow-x: auto; }
  .nj-cat { flex-shrink: 0; }
  .nj-grid { grid-template-columns: repeat(2, 1fr); }
  .nj-h1 { font-size: 32px; }
}
@media (max-width: 640px) {
  .nj-feat-grid { grid-template-columns: 1fr; }
  .nj-hero-right { width: 100%; }
  .nj-search { flex: 1; width: auto; }
}
</style>
