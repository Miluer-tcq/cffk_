import type { AlipayConfig, EmailProviderConfig, EmailTemplateConfig } from "@/lib/config-schemas";

// Persist these values with JSON.stringify() in D1. Payment credentials are
// entered by the administrator and are never returned to the browser. Payment
// URLs are paths; the current site origin is added when a payment is created.
export const alipayConfig = {
  schemaVersion: 1,
  modes: ["web", "face_to_face"],
  baseUrl: "https://openapi.alipay.com",
  appId: "2026xxxxxxxxxxxx",
  sellerId: "2088xxxxxxxxxxxx",
  privateKey: "-----BEGIN PRIVATE KEY-----\n...",
  alipayPublicKey: "-----BEGIN PUBLIC KEY-----\n...",
  notifyUrl: "/api/payments/alipay/notify",
  returnUrl: "/payment-result",
} satisfies AlipayConfig;

export const smtpEmailConfig = {
  kind: "smtp",
  host: "smtp.example.com",
  port: 465,
  secure: true,
  username: "orders@example.com",
  password: "smtp-authorization-code",
  from: "CFFK <orders@example.com>",
} satisfies EmailProviderConfig;

export const deliverySuccessTemplate = {
  subject: "{{siteName}} - Your order {{orderNo}} has been delivered",
  body: "Order: {{orderNo}}\nProduct: {{productName}}\nItems:\n{{deliveryItems}}",
  format: "text",
  variables: ["siteName", "orderNo", "productName", "deliveryItems"],
} satisfies EmailTemplateConfig;
