<template>
  <footer id="about" class="nj-footer">
    <div class="nj-footer-grid">
      <div class="nj-fbrand">
        <div class="nj-flogo">
          <span class="nj-logo-icon">
            <svg viewBox="0 0 24 24" fill="none"><path d="M12 2C13 8.5 15.5 11 22 12 15.5 13 13 15.5 12 22 11 15.5 8.5 13 2 12 8.5 11 11 8.5 12 2Z" fill="#fff"/></svg>
          </span>
          <b>{{ siteName }}</b>
        </div>
        <p>{{ tagline }}</p>
      </div>
      <div class="nj-fcol">
        <h4>快速链接</h4>
        <a href="/">购物</a>
        <a :href="user ? '/account/order' : '/order'">查订单</a>
        <a :href="user ? '/account' : '/login'">个人中心</a>
      </div>
      <div class="nj-fcol">
        <h4>帮助中心</h4>
        <a href="#">使用教程</a>
        <a href="#notice">网站公告</a>
        <a :href="supportHref" :target="supportExternal ? '_blank' : undefined" rel="noopener noreferrer">联系客服</a>
      </div>
      <div class="nj-fcol">
        <h4>联系我们</h4>
        <p class="nj-fcontact">在线客服实时响应<br />工作时间 9:00-23:00</p>
        <a :href="supportHref" :target="supportExternal ? '_blank' : undefined" rel="noopener noreferrer" class="nj-service-btn">
          <HeadphonesIcon /><span>在线客服</span>
        </a>
      </div>
    </div>
    <div class="nj-fbot">© {{ year }} {{ siteName }}</div>
  </footer>
</template>

<script setup lang="ts">
import { computed } from "vue";
import { HeadphonesIcon } from "@lucide/vue";
import { usePageContext } from "vike-vue/usePageContext";
import { useStorefrontPreferences } from "@/lib/storefront-preferences";

type Site = { name?: string | null; subtitle?: string | null; supportContact?: string | null };
type PublicUser = { id: string };
type PageContext = ReturnType<typeof usePageContext> & { site?: Site | null; user?: PublicUser | null };

const pageContext = usePageContext() as PageContext;
const user = computed(() => pageContext.user ?? null);
const siteName = computed(() => pageContext.site?.name?.trim() || "CFFK-Shop");
const { messages } = useStorefrontPreferences();
const tagline = computed(() => pageContext.site?.subtitle?.trim() || messages.value.storefront.fallbackSubtitle);
const year = new Date().getFullYear();

const supportHref = computed(() => {
  const first = (pageContext.site?.supportContact ?? "").split("\n").map((l) => l.trim()).find(Boolean) ?? "";
  if (!first) return "#";
  const address = first.includes("|") ? first.slice(first.indexOf("|") + 1).trim() : first;
  return address.includes(":") ? address : `mailto:${address}`;
});
const supportExternal = computed(() => supportHref.value.startsWith("http"));
</script>

<style scoped>
.nj-footer { background: var(--nj-card); border-top: 1px solid var(--nj-border); margin-top: 56px; }
.nj-footer-grid {
  max-width: 1200px; margin: 0 auto; padding: 44px 24px 30px;
  display: grid; grid-template-columns: 1.4fr 1fr 1fr 1fr; gap: 32px;
}
.nj-flogo { display: flex; align-items: center; gap: 10px; margin-bottom: 12px; }
.nj-logo-icon {
  width: 36px; height: 36px; border-radius: 50%;
  background: linear-gradient(135deg, #14b8a6, #0d9488);
  display: flex; align-items: center; justify-content: center;
  box-shadow: 0 4px 12px rgba(20, 184, 166, 0.35);
}
.nj-logo-icon svg { width: 18px; height: 18px; }
.nj-flogo b { font-size: 16px; font-weight: 800; color: var(--nj-text); }
.nj-fbrand p { font-size: 13px; color: var(--nj-muted); line-height: 1.7; margin: 0; }
.nj-fcol h4 { font-size: 14px; font-weight: 700; color: var(--nj-text); margin: 0 0 14px; }
.nj-fcol a { display: block; font-size: 13px; color: var(--nj-text-2); text-decoration: none; margin-bottom: 10px; }
.nj-fcol a:hover { color: #14b8a6; }
.nj-fcontact { font-size: 13px; color: var(--nj-muted); line-height: 1.8; margin: 0 0 14px; }
.nj-service-btn {
  display: inline-flex !important; align-items: center; gap: 8px;
  background: linear-gradient(135deg, #14b8a6, #0d9488); color: #fff !important;
  padding: 10px 20px; border-radius: 999px; font-size: 13px; font-weight: 600;
  box-shadow: 0 4px 12px rgba(20, 184, 166, 0.35); margin-bottom: 0 !important;
}
.nj-service-btn svg { width: 15px; height: 15px; }
.nj-service-btn:hover { color: #fff !important; transform: translateY(-1px); }
.nj-fbot {
  max-width: 1200px; margin: 0 auto; padding: 18px 24px;
  border-top: 1px solid var(--nj-border); font-size: 12px; color: var(--nj-muted); text-align: center;
}
@media (max-width: 768px) {
  .nj-footer-grid { grid-template-columns: 1fr 1fr; }
}
</style>
