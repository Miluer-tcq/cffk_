<template>
  <header class="nj-header">
    <div class="nj-header-inner">
      <a href="/" class="nj-logo" aria-label="返回首页">
        <span class="nj-logo-icon">
          <svg viewBox="0 0 24 24" fill="none"><path d="M12 2C13 8.5 15.5 11 22 12 15.5 13 13 15.5 12 22 11 15.5 8.5 13 2 12 8.5 11 11 8.5 12 2Z" fill="#fff"/></svg>
        </span>
        <b>{{ siteName }}</b>
      </a>

      <nav class="nj-nav" aria-label="主导航">
        <a href="/" class="nj-pill nj-pill-active"><ShoppingBagIcon /><span>购物</span></a>
        <a :href="user ? '/account/order' : '/order'" class="nj-pill"><ClipboardListIcon /><span>查订单</span></a>
        <a href="#" class="nj-pill"><BookOpenIcon /><span>使用教程</span></a>
        <a href="#" class="nj-pill"><FingerprintIcon /><span>动态验证</span></a>
        <a :href="supportHref" class="nj-pill" :target="supportExternal ? '_blank' : undefined" rel="noopener noreferrer"><HeadphonesIcon /><span>在线客服</span></a>
        <a href="#notice" class="nj-pill"><MegaphoneIcon /><span>公告</span></a>
        <a href="#about" class="nj-pill"><InfoIcon /><span>关于</span></a>
        <a :href="user ? '/account' : '/login'" class="nj-pill"><CircleUserRoundIcon /><span>个人中心</span></a>
      </nav>

      <div class="nj-actions">
        <DropdownMenu>
          <DropdownMenuTrigger as-child>
            <button type="button" class="nj-icon-btn" aria-label="切换语言" title="语言">
              <LanguagesIcon />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" :side-offset="8" class="w-36">
            <DropdownMenuLabel>{{ messages.preferences.language }}</DropdownMenuLabel>
            <DropdownMenuSeparator />
            <DropdownMenuItem @select="setLocale('zh-CN')">{{ zhCN.languageName }}</DropdownMenuItem>
            <DropdownMenuItem @select="setLocale('zh-TW')">{{ zhTW.languageName }}</DropdownMenuItem>
            <DropdownMenuItem @select="setLocale('en-US')">{{ enUS.languageName }}</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        <button
          type="button"
          class="nj-icon-btn"
          :aria-label="theme === 'light' ? messages.preferences.dark : messages.preferences.light"
          @click="setTheme(theme === 'light' ? 'dark' : 'light')"
        >
          <SunIcon v-if="theme === 'light'" />
          <MoonIcon v-else />
        </button>
        <a v-if="!user" href="/login" class="nj-icon-btn" aria-label="登录">
          <CircleUserRoundIcon />
        </a>
        <a v-else href="/account" class="nj-avatar" :aria-label="currentUserName" :title="currentUserName">
          {{ userInitials }}
        </a>
      </div>
    </div>
  </header>
</template>

<script setup lang="ts">
import { computed } from "vue";
import {
  BookOpenIcon,
  CircleUserRoundIcon,
  ClipboardListIcon,
  FingerprintIcon,
  HeadphonesIcon,
  InfoIcon,
  LanguagesIcon,
  MegaphoneIcon,
  MoonIcon,
  ShoppingBagIcon,
  SunIcon,
} from "@lucide/vue";
import { usePageContext } from "vike-vue/usePageContext";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import enUS from "@/lib/i18n/en-US";
import zhCN from "@/lib/i18n/zh-CN";
import zhTW from "@/lib/i18n/zh-TW";
import { useStorefrontPreferences } from "@/lib/storefront-preferences";

type Site = { name?: string | null; supportContact?: string | null };
type PublicUser = { id: string; name?: string | null; email?: string | null };
type PageContext = ReturnType<typeof usePageContext> & { site?: Site | null; user?: PublicUser | null };

const pageContext = usePageContext() as PageContext;
const user = computed(() => pageContext.user ?? null);
const siteName = computed(() => pageContext.site?.name?.trim() || "CFFK-Shop");
const currentUserName = computed(() => user.value?.name?.trim() || user.value?.email || "");
const userInitials = computed(() => currentUserName.value.slice(0, 1).toUpperCase() || "我");
const { messages, setLocale, setTheme, theme } = useStorefrontPreferences();

const supportHref = computed(() => {
  const first = (pageContext.site?.supportContact ?? "").split("\n").map((l) => l.trim()).find(Boolean) ?? "";
  if (!first) return "#";
  const address = first.includes("|") ? first.slice(first.indexOf("|") + 1).trim() : first;
  return address.includes(":") ? address : `mailto:${address}`;
});
const supportExternal = computed(() => supportHref.value.startsWith("http"));
</script>

<style scoped>
.nj-header {
  position: sticky;
  top: 0;
  z-index: 50;
  background: color-mix(in srgb, var(--nj-card) 92%, transparent);
  backdrop-filter: blur(12px);
  border-bottom: 1px solid var(--nj-border);
}
.nj-header-inner {
  max-width: 1200px;
  margin: 0 auto;
  padding: 12px 24px;
  display: flex;
  align-items: center;
  gap: 18px;
}
.nj-logo {
  display: flex;
  align-items: center;
  gap: 10px;
  text-decoration: none;
  flex-shrink: 0;
}
.nj-logo-icon {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  background: linear-gradient(135deg, #14b8a6, #0d9488);
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow: 0 4px 12px rgba(20, 184, 166, 0.35);
}
.nj-logo-icon svg { width: 20px; height: 20px; }
.nj-logo b { font-size: 17px; font-weight: 800; color: var(--nj-text); letter-spacing: 0.5px; }
.nj-nav {
  display: flex;
  align-items: center;
  gap: 4px;
  background: var(--nj-nav-bg);
  border-radius: 999px;
  padding: 5px;
  margin: 0 auto;
  overflow-x: auto;
  scrollbar-width: none;
}
.nj-nav::-webkit-scrollbar { display: none; }
.nj-pill {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 15px;
  border-radius: 999px;
  font-size: 13.5px;
  font-weight: 500;
  color: var(--nj-text-2);
  text-decoration: none;
  white-space: nowrap;
  transition: all 0.18s;
}
.nj-pill svg { width: 15px; height: 15px; }
.nj-pill:hover { color: #14b8a6; background: rgba(20, 184, 166, 0.08); }
.nj-pill-active {
  background: linear-gradient(135deg, #14b8a6, #0d9488);
  color: #fff;
  font-weight: 600;
  box-shadow: 0 4px 12px rgba(20, 184, 166, 0.35);
}
.nj-pill-active:hover { color: #fff; background: linear-gradient(135deg, #14b8a6, #0d9488); }
.nj-actions { display: flex; align-items: center; gap: 10px; flex-shrink: 0; }
.nj-icon-btn {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  border: 1px solid var(--nj-input-border);
  background: var(--nj-card);
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--nj-text-2);
  cursor: pointer;
  transition: all 0.18s;
  text-decoration: none;
}
.nj-icon-btn svg { width: 17px; height: 17px; }
.nj-icon-btn:hover { border-color: #14b8a6; color: #14b8a6; }
.nj-avatar {
  width: 38px;
  height: 38px;
  border-radius: 50%;
  background: linear-gradient(135deg, #14b8a6, #0d9488);
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 15px;
  font-weight: 700;
  text-decoration: none;
}
@media (max-width: 1024px) {
  .nj-nav .nj-pill span { display: none; }
  .nj-pill { padding: 8px 11px; }
}
@media (max-width: 640px) {
  .nj-nav { display: none; }
}
</style>
