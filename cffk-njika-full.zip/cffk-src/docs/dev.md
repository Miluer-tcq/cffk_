# 项目背景
开发前请`阅读 docs 文档了解项目背景和编码规则`。
本项目 cffk 是一个基于 Vike 的全栈发卡站，前端、Telefunc 服务端和数据库统一开发、统一部署，运行在 Cloudflare Workers 环境。功能升级默认前后端同步升级，不需要为本项目内部接口保留旧请求参数、旧响应结构或旧业务接口兼容层；修改接口时应直接同步修改所有调用方，删除已经废弃的参数和逻辑。

兼容性规则：
- 必须兼容旧数据库中的已有数据。涉及数据库表结构、字段、索引或数据回填的改动，必须新增对应的 `database/migrations/*.sql` 迁移文件，禁止直接修改已执行的历史迁移文件；迁移应包含必要的默认值、历史数据回填和约束验证。
- 必须保证迁移后旧商品、卡密、订单等历史数据仍能被正常读取和处理；需要时通过迁移回填新字段，而不是在业务接口中长期保留旧请求格式。
- 不需要兼容旧的前端请求参数、Telefunc 入参、接口响应结构、内部函数签名或旧业务流程。前后端属于同一项目，升级时直接同步修改调用方和被调用方。
- 不需要为了“可能存在的外部调用方”增加兼容适配层；除非任务明确要求对外公开 API 兼容，否则以当前代码库的新数据结构和新接口为准。
- 数据库迁移完成后，业务代码应使用新的规范结构；旧数据库字段仅在确有历史数据读取、迁移回填或现有数据库约束需要时保留，不得继续作为新功能的首选写入结构。

# Vike-CF 开发规范

本规范适用于 `vike-cf` 的业务页面、Telefunc 接口和后台管理功能。目标是让页面交互、数据列表和错误反馈保持一致，避免在业务页面重复造 UI 或把临时反馈渲染成常驻内容。

错误信息按本文第 5 节的三层规则处理：前端必须脱敏；数据库业务日志仅移除 `sign` 与密钥；未预期异常的完整接口信息和原始错误输出到 Cloudflare Workers Observability，供 root 在 Cloudflare 控制台排查。

权限模型仅包含 `guest`、`user`、`root` 三种身份，且项目只保留一个 `root`。不新增多角色、权限点、审批或审计系统。

管理员登录只能从 `/${ADMIN_PATH}` 入口发起，前端请求必须携带 `x-cffk-admin-login: 1`。公共 `/login` 命中 root 管理员账号时，服务端必须返回与普通错误密码完全一致的 `401 INVALID_EMAIL_OR_PASSWORD`，不得创建会话、跳转后台或暴露该账号的管理员身份；此规则用于减少管理员账号被公开登录入口爆破的风险。

删除数据库必须先备份。

## 1. UI 组件原则

### 1.1 优先使用项目已有组件

业务页面必须优先复用 `components/ui` 与 `components/admin` 中的组件：

- 输入：`Input`、`Textarea`、`Select`、`Checkbox`
- 日期：`DatePicker`（`Popover` + `Calendar` 封装）
- 按钮：`Button`
- 展示：`Card`、`Badge`
- 对话框：`reka-ui` 的 `DialogRoot` 家族
- 后台列表：`AdminDataTable`
- 分页：`Pagination`

禁止在业务页面直接新增原生 `<input>`、`<select>`、`<textarea>`、`<button>` 来绕开统一样式与交互。原生标签只应作为 UI 基础组件的内部实现。

如发现当前组件库缺少需要的能力，先确认 shadcn-vue 是否有官方组件；通过 CLI 添加并按项目风格封装，而不是在单个页面手写一套无法复用的控件。

### 1.2 临时反馈使用 Sonner Toast

成功、失败、校验提醒等**短暂反馈**必须使用 `vue-sonner`：

```ts
import { toast } from "vue-sonner";

toast.success("卡密已导入。");
toast.error("请先选择商品。");
toast.info("数据已刷新。");
```

全局 `Toaster` 由 `pages/+Layout.vue` 统一挂载，并必须同时导入官方样式：

```vue
<script setup lang="ts">
import { Toaster } from "vue-sonner";
import "vue-sonner/style.css";
</script>

<template>
  <slot />
  <Toaster rich-colors position="top-right" :offset="16" />
</template>
```

不要在业务页面为一次操作失败渲染顶部或底部常驻 `Alert`。它会挤占页面布局、在切换操作后残留，并且在未正确挂载样式时容易被误当成普通文档流内容。

`Alert` 仅用于需要持续展示、且用户必须阅读的页面级状态，例如服务维护公告、无法继续工作的初始化失败状态，或不可忽略的配置告警。

### 1.3 后台表单

后台新增或重构的非平凡表单（包含多个字段、保存请求或业务校验）必须采用 `VeeValidate + Zod + shadcn-vue Field`：

- 通过 `vee-validate` 的 `useForm()` 管理表单状态，使用 `Field as VeeField` 为每个字段建立绑定；`Input`、`Textarea`、`Select` 等组件使用 `v-bind="componentField"`。
- 使用 `zod` 定义客户端 schema，并通过 `@vee-validate/zod` 的 `toTypedSchema()` 接入。客户端校验用于即时反馈，不可替代 Telefunc 服务端校验。
- 字段外层使用 `Field`、`FieldLabel`、`FieldDescription` 和 `FieldError`；字段组使用 `FieldGroup`，语义分组使用 `FieldSet`、`FieldLegend` 和 `FieldSeparator`。不得在业务页面用手写 `<label>` 加 class 替代该结构。
- 发生校验错误时，`Field` 必须设置 `:data-invalid="errors.length > 0"`，对应控件必须设置 `:aria-invalid="errors.length > 0"`，并通过 `FieldError` 紧邻展示错误。
- 表单使用 `novalidate`，由 Zod/VeeValidate 统一呈现客户端错误；仍可保留合适的输入属性，例如 `type="url"`、`autocomplete` 和 `inputmode`，以改善输入体验。
- 表单初始加载或重新加载数据时使用 `resetForm({ values })`，避免直接修改组件局部状态导致 VeeValidate 值不同步。
- 保存成功和服务端拒绝等短暂反馈使用 `runTelefunc()` 与 Sonner Toast；仅无法继续操作的加载失败可使用页面级 `Alert`。提交期间必须禁用提交按钮。
- `Select`、`Checkbox`、`Switch` 等非文本控件须按 shadcn-vue 文档绑定。特别是 `Select` 要将 `componentField` 绑定到 `Select` 根组件，而不是 `SelectTrigger`。

服务端仍必须对所有输入进行完整权限、格式、长度和业务状态校验；客户端 schema 仅是提升体验的第一道校验。

### 1.4 新增与编辑交互

实体的简单新增和编辑表单使用 `DialogRoot` 弹窗承载，不在列表下方插入长表单。包含富文本编辑器、多个字段组或需要长页面滚动的完整编辑器必须使用独立路由页面，避免窄弹窗与双重滚动；列表中的新建和编辑操作跳转至该页面，保存后返回列表。快速添加等少量必要字段的流程可继续使用弹窗。

- 弹窗内容超出视口时，内容区必须 `overflow-y-auto`，保存操作固定在底部，避免长配置表单需要滚动到页面末尾才能提交。
- 表单有未保存输入时，禁止通过点击遮罩或 `Escape` 意外关闭；提供明确的“关闭”或“取消”操作。
- 不可恢复的删除操作仍单独使用确认 Dialog，不与新增/编辑表单共用。

```vue
<VeeField v-slot="{ componentField, errors }" name="siteName" :validate-on-input="true">
  <Field :data-invalid="errors.length > 0">
    <FieldLabel for="site-name">站点名称</FieldLabel>
    <Input id="site-name" v-bind="componentField" :aria-invalid="errors.length > 0" />
    <FieldError v-if="errors.length" :errors="errors" />
  </Field>
</VeeField>
```

### 1.5 金额与货币单位

金额采用明确的双层单位边界，禁止在同一业务边界混用“元”和“分”：

- 数据库金额列、订单计算、库存和优惠结算、支付回调核验及支付渠道适配器内部，统一使用非负整数“分”。
- 前端输入、页面展示、公开和后台 Telefunc 的业务 DTO、运营文案及校验提示，统一使用“元”。用户可见的标签、说明和错误信息不得出现“分”。
- 元金额必须以最多两位小数的字符串传递，例如 `"12.30"`；不得以 JavaScript 浮点数作为金额契约。
- 元与分只能通过 `lib/payment-utils.ts` 的 `parseAmountToCents()` 和 `formatCentsAsYuan()` 转换。禁止在业务表单、页面或 Telefunc 中散落使用 `Number(value) * 100`、`/ 100` 或自行四舍五入。
- 固定优惠金额和最低订单金额按元处理；百分比优惠保持整数百分比。
- 支付渠道适配器是唯一可以将内部“分”换算为第三方渠道金额单位的边界。
- 新增或修改金额字段时，必须补充“元输入 -> 分存储”和“分读取 -> 元输出”的测试，并确认用户可见文案不出现“分”。

### 1.6 色彩

全站 UI 使用组件默认的黑、白、灰色阶作为基础色，并仅使用 Logo 的蓝色与橙色作为品牌强调色。不得新增红色、绿色、黄色、紫色等独立状态色；破坏性操作和真实错误仍使用组件语义色 `destructive`。

- 需要用户处理但尚未构成错误的状态（如“配置不完整”“库存不足”）使用 Logo 橙色：`border-orange-500/30 bg-orange-500/10 text-orange-600 dark:text-orange-400`。
- 正常、已启用、已完成等状态优先使用组件的 `secondary` 或 `outline`，不额外引入绿色。
- 蓝色仅用于品牌识别、链接和明确的主操作；不要将蓝色与橙色同时用作同一状态。

### 1.7 公开商城首页

首页（`pages/index/+Page.vue`）遵循以下固定结构与视觉规则：

- 顶部固定导航：展示 Logo 与站点名称；首页不显示“首页”按钮，只显示“我的订单”和可选的联系支持。非首页公开页才提供返回首页入口。
- 公告与搜索：不在 Hero 区重复展示站点名称；公告在左、商品搜索在右。搜索应与分类筛选同时生效。
- 商品区：分类筛选与商品列表同处；商品卡片使用固定横向封面比例，未配置封面时使用 `assets/product_img.jpg`，图片以 `object-cover` 填满图片区。
- 商品卡片仅展示分类、名称/副标题、库存或发货说明与价格；点击整张卡片进入商品详情，不额外堆叠重复的“查看商品”按钮。
- 色彩：遵循全站色彩规范。缺货状态使用 Logo 橙色（`text-orange-500`），普通库存说明使用 `text-muted-foreground`；不得使用 `text-destructive`。

### 1.8 破坏性操作

删除、清空、关闭等不可恢复的操作必须：

1. 使用 `DialogRoot` 确认，不依赖浏览器 `confirm()`。
2. 明确说明影响范围与不可恢复性。
3. 提交期间禁用确认按钮，避免重复请求。
4. 服务端再次校验目标状态/权限，不能只依赖前端禁用。
5. 成功或失败后使用 Toast 反馈结果。

```ts
function requestDelete(row: Row) {
  rowToDelete.value = row;
  deleteDialogOpen.value = true;
}

async function deleteRow() {
  if (!rowToDelete.value) return;
  saving.value = true;
  try {
    await onDeleteRow({ id: rowToDelete.value.id });
    deleteDialogOpen.value = false;
    toast.success("记录已删除。");
    await loadData();
  } catch {
    // runTelefunc 已显示脱敏错误提示。
  } finally {
    saving.value = false;
  }
}
```

## 2. 后台信息架构、目录与导航元数据

后台导航、路由、页面目录和面包屑必须使用同一棵层级树，唯一来源为 `lib/admin-navigation.ts`。禁止侧栏、模块内部导航、面包屑和文件目录各自维护一套层级或路径。

### 2.1 层级、目录与路由

后台最多三级：**一级菜单分组 -> 二级模块或页面 -> 三级模块页**。

- **一级菜单**是业务分组，只负责归类，不生成同名页面或 URL。它对应稳定路由前缀和 `pages/@adminPath/<prefix>/` 目录。
- **二级菜单**是侧栏在一级分组下显示的可访问项。二级模块的首页为 `/<prefix>/<module>`。
- **三级菜单**是二级模块的内部页面，路径为 `/<prefix>/<module>/<page>`。三级项只在该模块内部导航显示，绝不与二级项并列显示在侧栏，也不能有第二个入口。
- 仅不属于业务分组的独立页面可使用根级路径，例如 `/dash`、`/orders`。
- URL 必须与 `pages/@adminPath` 的相对目录一一对应；一个页面只能有一个正式 URL。修改路径时移动真实目录、更新集中元数据和调用方、删除旧目录。不得保留兼容跳转、别名 URL、平行路径或重复菜单入口。

当前正式结构：

| 一级菜单 | 正式路由前缀 | 页面目录 | 二级项 | 三级项 |
| --- | --- | --- | --- | --- |
| 面板 | `/dash` | `pages/@adminPath/dash` | 面板 | 无 |
| 商品管理 | `/catalog/*` | `pages/@adminPath/catalog` | 分类、商品、卡密、折扣码 | 无 |
| 订单管理 | `/orders` | `pages/@adminPath/orders` | 订单管理 | 无 |
| 推送管理 | `/push/*` | `pages/@adminPath/push` | 推送配置、消息模板、电子邮件、微信三方、Telegram、发送日志 | 电子邮件：邮件统计、通道配置 |
| 系统配置 | `/system/*` | `pages/@adminPath/system` | 支付渠道、媒体存储、站点配置、安全配置、任务 | 无 |
| 用户管理 | — | — | 当前不提供用户或管理员管理页面；唯一 root 仅由 `adminBootstrap(id=1)` 指定 | 无 |

电子邮件模块的唯一首页为 `/push/email`；其三级页面只能为 `/push/email/post-office`。消息模板是 `/push/templates` 的推送管理二级页面。不得再创建 `/mail/*`、`/notifications/*`、`/push/email/overview` 或任何兼容入口。

### 2.2 集中元数据

所有后台业务页面都必须在 `lib/admin-navigation.ts` 的 `adminPages` 注册，且页面元数据必须完整包含：

```ts
{
  title: "侧栏与面包屑名称",
  path: "/route-path",
  pageTitle: "页面 H1",
  description: "页面副标题",
}
```

`adminPages` 与 `adminNavigation` 是后台信息架构的唯一来源：

- `title` 用于侧栏、模块导航和面包屑。
- `pageTitle` 和 `description` 用于 `AdminPageHeader` 或模块布局的页头。
- `AdminSidebar`、后台 Layout 与模块内部导航只能引用这些集中定义，不得复制标题或维护页面私有路由映射。
- 二级模块以 `AdminNavigationModule` 定义其三级页面；模块首页元数据和三级页元数据都在 `adminPages` 注册。

新增或调整后台页面时：

1. 在 `adminPages` 注册页面元数据。
2. 将页面或二级模块加入既有 `adminNavigation` 一级分组，不复制 `title`、`path`。
3. 在 `pages/@adminPath` 创建与 `path` 一致的 `+Page.vue`；普通页面顶层使用 `<AdminPageHeader />`。
4. 新增三级页时，把它加入所属二级模块的 `items`；不得加入一级菜单的二级项列表。
5. 不能实现的菜单功能必须提供真实空状态页，不能保留无效链接或伪造可保存配置。

登录页和其他认证入口不属于后台业务页面，无需注册为 `adminPages`。

## 3. 后台列表规范

### 2.1 必须使用 `AdminDataTable`

所有后台管理中的实体列表（商品、订单、卡密、优惠码、媒体文件、推送记录等）必须使用：

```vue
<AdminDataTable :columns="columns" :rows="data.items" row-key="id">
  <template #toolbar><!-- 筛选、刷新、新增操作 --></template>
  <template #cell-status="{ row }"><Badge>{{ row.status }}</Badge></template>
  <template #actions="{ row }"><!-- 行操作 --></template>
  <template #pagination><!-- Pagination --></template>
</AdminDataTable>
```

详细 API 见 [components.md](./components.md)。实体列表没有行操作时必须传 `:show-actions="false"`；仪表盘摘要表不是实体管理列表，可使用基础 `Table`。

### 2.2 一项业务字段对应一列

`columns` 必须让每一个业务字段对应单独的列。例如卡密列表应拆成：`商品`、`卡密预览`、`批次`、`状态`、`订单`、`创建时间`，不能把多项信息堆叠在一个 `#cell-*` 单元格中。

```ts
const columns: AdminTableColumn<CardRow>[] = [
  { key: "id", label: "ID" },
  { key: "productName", label: "商品" },
  { key: "contentPreview", label: "卡密预览" },
  { key: "batchNo", label: "批次" },
  { key: "status", label: "状态" },
  { key: "orderId", label: "订单" },
  { key: "createdAt", label: "创建时间" },
];
```

仅当字段需要格式化时使用 `#cell-{key}` 插槽，例如状态 Badge、金额、日期或截断文本。不要为了布局把其它字段塞入该插槽。

### 2.3 工具栏与筛选布局

- 工具栏放在 `#toolbar`。
- 筛选条件与页面操作分组展示；筛选项置于左侧，新增、刷新、导入等页面操作按钮统一置于右侧。仅有操作按钮时，仍使用占满工具栏宽度的右对齐操作组。
- 筛选项按内容语义设置最小宽度和伸缩规则，不要所有控件机械使用同一固定宽度。
- 商品名称通常比状态更长；日期控件必须留出完整中文日期的宽度；按钮按内容宽度，不参与拉伸。
- 使用 `flex flex-wrap` 配合合理的 `min-w-*`/`flex-*` 实现响应式布局。宽度不足时允许换行，不要压缩到文字溢出。
- 搜索、重置应显式触发请求；筛选选择框不应通过关闭菜单等隐式事件请求数据。
- 更改任意查询条件或每页条数时，将页码重置为第 1 页。

### 2.4 敏感字段的列表投影

列表接口只能返回页面所需字段。密钥、卡密全文、令牌、密码、支付敏感信息等不得直接返回给列表 UI。

服务端应生成显示安全的字段，例如：

```ts
function previewCard(content: string) {
  return content.length <= 8
    ? content
    : `${content.slice(0, 4)}****${content.slice(-4)}`;
}

return {
  items: rows.map(({ content, ...row }) => ({
    ...row,
    contentPreview: previewCard(content),
  })),
};
```

不要把原始 `content` 发给前端后再隐藏；浏览器网络响应和开发工具仍可读取它。

## 4. 列表 Telefunc 接口契约

### 4.1 查询参数

列表查询函数使用一个对象参数，所有筛选条件可选，分页参数统一命名：

```ts
type EntityListQuery = {
  keyword?: string;
  status?: EntityStatus;
  productId?: number;
  startDate?: string; // YYYY-MM-DD
  endDate?: string;   // YYYY-MM-DD，服务端按结束日次日零点排他处理
  page?: number;
  pageSize?: number;
};

export async function onGetEntityAdminData(input: EntityListQuery = {}) {
  // ...
}
```

服务端必须校正而不是相信客户端分页值：

```ts
const page = Math.max(1, Math.floor(input.page ?? 1));
const pageSize = Math.min(100, Math.max(10, Math.floor(input.pageSize ?? 20)));
```

日期、枚举、数字 ID 和字符串长度必须在服务端验证。日期推荐在接口边界转换为精确的起始时间和结束日的**排他**边界，避免当天晚些时候的数据被遗漏。

### 4.2 返回结构

管理列表应返回能直接驱动 `AdminDataTable` 和 `Pagination` 的对象：

```ts
type EntityListResult = {
  items: EntityRow[];
  total: number;
  page: number;
  pageSize: number;
  // 页面筛选所需的辅助数据可附在此处。
  products: Array<{ id: number; name: string }>;
  overview?: {
    total: number;
    available: number;
    sold: number;
  };
};
```

约束：

- `items` 仅包含当前页行数据。
- `total` 是**当前筛选条件**下的总数，供 `Pagination` 计算页数。
- `page`、`pageSize` 返回服务端最终采用的值，避免前后端状态漂移。
- 全局概览（如总库存）必须明确是否不受筛选条件影响；默认应作为全局统计单独查询，不能误用当前页或当前筛选的 `total`。
- 关联显示字段（如 `productName`）在服务端 join/投影完成，避免前端用多次请求拼接。

页面侧保持查询状态，由页面负责请求：

```ts
const data = reactive<EntityListResult>({
  items: [], total: 0, page: 1, pageSize: 20, products: [],
});
const page = ref(1);
const pageSize = ref(20);

async function loadData() {
  try {
    const result = await runTelefunc(
      () => onGetEntityAdminData({
        ...filters,
        page: page.value,
        pageSize: pageSize.value,
      }),
      { notifyError: false },
    );
    Object.assign(data, result);
  } catch (cause) {
    loadError.value = userErrorMessage(cause);
  }
}
```

## 5. Telefunc 错误设计与统一处理

### 5.1 调用边界：Telefunc 与 HTTP API 分开规范

项目同时使用 Telefunc RPC 和少量 Hono HTTP 接口；两者不能混用响应约定。

- **页面到项目服务端的业务调用：使用 Telefunc。** 成功时直接返回业务数据；领域层以 `AppError` 表示预期业务失败，Telefunc 导出入口再通过 `telefuncAction()` 将其转换为携带稳定错误码的 `Abort`。不要直接让普通 `Error` 或 `AppError` 穿过 Telefunc 边界，也不要为 Telefunc 添加 `{ code, message, data }` 包装层。
- **公开或第三方 HTTP API：使用 HTTP 状态码与 JSON 信封** `{ code, message, data }`。`code: 0` 代表成功；`400/401/403/404/409` 携带稳定业务码；未预期异常返回 `500` 和 `INTERNAL_ERROR`。
- **协议回调例外：** 支付回调等由第三方协议规定响应格式的路由，保留协议要求的纯文本/签名响应，不能强制套 JSON 信封。

### 5.2 Telefunc 服务端：稳定错误码，不泄露内部信息

`AppError` 是项目的领域错误，只用于表示权限、输入校验、状态机校验等预期业务失败。领域代码通过 `appError()` 或 `throw new AppError(code)` 抛出稳定、全大写的业务错误码：

```ts
if (!context.user || !context.isAdmin) {
  appError("ADMIN_ACCESS_REQUIRED");
}
if (!Number.isInteger(input.id) || input.id < 1) {
  appError("ENTITY_ID_INVALID");
}
if (!record) {
  appError("ENTITY_NOT_FOUND");
}
if (record.status !== "DRAFT") {
  appError("ENTITY_DELETE_REJECTED");
}
```

所有 `server/**/*.telefunc.ts` 中导出的 `on*` 入口必须由 `@/server/telefunc-action` 的 `telefuncAction()` 包装：

```ts
import { telefuncAction } from "@/server/telefunc-action";

async function internalOnDeleteEntity(input: { id: number }) {
  // 领域服务可抛出 AppError。
}

export const onDeleteEntity = telefuncAction(internalOnDeleteEntity);
```

`telefuncAction()` 是领域层与 Telefunc 协议之间唯一的错误转换边界：它只把 `AppError` 转换为 `Abort({ code })`，供客户端通过 `errorCode()` 读取；普通 `Error` 和其他真实异常必须保持原对象并原样抛出，使请求保持 `500` 语义并进入 Workers Observability。不得使用 `throw new Error("STABLE_CODE")` 表示业务失败，也不得在入口捕获真实异常后改造成业务错误码。

规则：

- 错误码使用 `UPPER_SNAKE_CASE`，按资源和语义命名，例如 `CARD_CONTENT_REQUIRED`、`PRODUCT_NOT_CARD_AUTO`、`CARD_DELETE_REJECTED`。
- 不将数据库异常、SQL、堆栈、第三方支付原始响应或敏感值直接传给客户端。
- 对“删除/状态切换”等并发敏感操作，将可操作状态写进 `where` 条件；根据 `returning()` 是否返回记录判断结果。
- 未预期异常必须保留原始异常与堆栈并进入 Cloudflare Workers Observability；客户端仍只显示通用错误文案。
- 数据库业务日志只脱敏 `sign`、密码、token、API key、Secret、私钥和 access key；不要将这些值写回支付、邮件或推送日志。

### 5.3 前端：必须通过 `runTelefunc()` 统一处理

所有会向用户反馈结果的 Telefunc 调用必须经由 `@/lib/telefunc-client` 的 `runTelefunc()`，不得在页面中直接调用后自行 `toast.error()` 或复制 `messageFor()`：

```ts
import { runTelefunc } from "@/lib/telefunc-client";

await runTelefunc(
  () => onDeleteCard({ id }),
  { successMessage: "卡密已删除。" },
);
```

`runTelefunc()` 统一处理：

- 成功时按需显示 `successMessage`；
- 已知业务错误码从 `lib/error-messages.ts` 映射为中文 Toast；
- 未知业务错误、网络传输失败、Telefunc 服务端 `500` 等显示统一文案：`接口异常，请稍后重试。`；
- 显示 Toast 后重新抛出异常，以便页面在 `finally` 里恢复 loading/saving 状态。

调用方只保留空的 `catch`（防止未处理 Promise）或仅处理页面状态；不要再次显示错误 Toast：

```ts
try {
  await runTelefunc(() => onSaveEntity(input), { successMessage: "保存成功。" });
  await loadData();
} catch {
  // runTelefunc 已显示统一错误提示。
} finally {
  saving.value = false;
}
```

`lib/error-messages.ts` 是业务错误码与用户中文文案的唯一映射源。新增 Telefunc 错误码时，必须同步添加该映射；不允许新增页面私有 `messageFor()`。

只有确实需要表单附近持续错误信息的场景（例如结算表单字段校验）可以使用 `runTelefunc(..., { notifyError: false })`，再将 `userErrorMessage(cause)` 写入本地表单状态；不能同时显示 Alert 和 Toast。

### 5.4 全局服务端错误处理与 Workers Observability

Hono、Telefunc 与 Vike SSR / `+data.server.ts` 的未预期异常都必须保留 `500` 语义并进入 Cloudflare Workers Observability，但各协议边界按各自机制处理，不能笼统地改写为同一种异常：

1. Hono 与 Vike 服务端边界使用项目的服务端错误处理设施记录原始 `Error`、堆栈和排查上下文，再按协议返回脱敏结果。
2. Telefunc 的 `telefuncAction()` 不记录或改写普通 `Error`；它原样抛出同一个异常对象，由 Telefunc/Workers 保持 `500` 和 Observability。只有 `AppError` 会转换为 `Abort({ code })`。
3. HTTP API 返回 `INTERNAL_ERROR` JSON；Telefunc 客户端由 `runTelefunc()` 映射为通用文案；支付回调按第三方协议返回 `failure`。
4. 不把 Observability 的原始内容复制到前端或数据库业务日志，也不记录 Secret。

`AppError` 是预期领域错误，不按未预期异常上报；经 Telefunc 边界转换后的业务错误码按 `lib/error-messages.ts` 映射并显示给用户。

### 5.5 Workers 日志采样与线上 500 排查

`wrangler.jsonc` 的 `observability.head_sampling_rate` 是**请求级 head-based sampling**，不是错误日志专用采样：

- 取值范围为 `0` 到 `1`；`0.1` 代表约 10% 的进入 Worker 的请求会被记录，`1` 代表全部请求。未配置时 Cloudflare 默认 `1`。
- 被选中的请求会收集该请求上下文中的 invocation log、`console.*` 日志、错误和未捕获异常；未被选中的请求不会因其恰好返回 `500` 而自动补采样。
- 调整采样率前必须先评估请求量、日志量和成本；不能因一次故障就把它误改成“错误采样率”。需要逐请求排查的低流量环境可配置 `1`，当前生产默认保留 `0.1`。

排查线上 `500` 时，Cloudflare 的 `GET <URL>` invocation log 只能说明请求和响应状态，不能说明 JavaScript 或 D1 异常根因。必须按 `requestId`、URL 和时间范围查询同一请求上下文中的 `Unhandled server error` 结构化日志，并读取其中的 `scope`、`error.message`、`error.stack` 与 `details`。若该请求未被采样，重新请求直到命中日志，或在短时间、低流量的排查窗口将采样率改为 `1` 并重新部署；排查结束后按流量策略恢复。

### 5.6 部署构建、迁移与验收

本项目是 Vike/Vite Worker：`wrangler deploy` 只上传已经生成的部署产物；它不会代替 `bun run build` 构建应用源码。`vike build` 会生成供 Wrangler 使用的部署配置和产物，因此手动部署必须走项目脚本：

- `bun run deploy`：依次执行远程 D1 迁移、远程种子、构建、`wrangler deploy`。仅用于需要初始化种子数据的新环境；已有生产环境不应无确认地重复写入种子。
- `bun run up`：依次执行远程 D1 迁移、构建、`wrangler deploy`，用于已有环境的常规发布。
- 不要以裸 `wrangler deploy` 代替上述脚本，也不要假设旧的 `dist` 可以代表当前源码。

README 中的 **Deploy to Cloudflare** 按钮使用 Workers Builds：Cloudflare 克隆仓库、读取 Wrangler 配置并自动创建所需绑定资源，然后构建并部署。它会从 `package.json` 识别并在配置页预填 `build`、`deploy` 脚本；部署者可以修改或接受这些命令。因此不能假定该按钮固定执行 `bun run deploy`，也不能假定它忽略构建。使用该按钮前必须在配置页核对实际 build/deploy 命令；D1 迁移必须由已确认的 deploy 脚本执行，并使用绑定名 `DB`，不能只依赖 Worker 发布自动完成迁移。

每次线上发布后必须：

1. 在发布输出中确认实际执行的构建与部署命令、Worker 名称和版本。
2. 访问公开 URL，至少验证首页、一个真实商品详情页和一个下单路径；不能只验证本地 `localhost`。
3. 若出现 `500`，按上一节获取同一 `requestId` 的 `Unhandled server error`，根据原始堆栈修复后重新发布；禁止以查询降级、字段默认值或吞掉异常替代根因修复。

### 5.7 HTTP API 客户端与 500 错误

Hono HTTP 接口在 `server/hono.ts` 统一处理未捕获异常：

```ts
{ code: "INTERNAL_ERROR", message: "接口异常，请稍后重试。", data: null }
```

并以 HTTP `500` 返回。新增 REST 客户端时，必须提供统一 `apiClient`：

```ts
const response = await fetch(url, options);
const body = await response.json();
if (!response.ok || body.code !== 0) {
  toast.error(errorMessages[body.code] ?? "接口异常，请稍后重试。");
  throw new Error(body.code ?? "INTERNAL_ERROR");
}
return body.data;
```

不要：

- 将 `Error.message`、数据库异常或第三方原始响应直接展示给用户。
- 把一次性操作错误写到页面常驻状态后不清除。
- 在 `catch` 中吞掉错误且没有任何用户反馈。
- 同时显示 Alert 与 Toast。
- 只在前端做“禁用按钮”等权限或状态校验。

## 6. 推送模块路由

推送模块的正式路由统一为 `/push/*`，页面与导航元数据必须使用同一条路径：

- `/push/config`：推送配置
- `/push/history`：发送日志
- `/push/email`：电子邮件二级模块首页（邮件统计）
- `/push/email/post-office`：电子邮件三级页面
- `/push/templates`：消息模板
- `/push/wecom`：微信三方
- `/push/telegram`：Telegram

电子邮件只作为“推送管理”下的一个二级模块显示一次；邮件统计和通道配置只能作为该模块的三级页面出现。消息模板是推送管理的并列二级项，供电子邮件、微信三方和 Telegram 共用。不得在推送模块新增或保留 `/mail/*`、`/notifications/*` 等平行路径。推送规则统一由 `server/push` 管理，页面通过推送配置决定订单事件是否向客户或唯一 root 投递。渠道实现实际投递时，必须同步写入 `pushLog`；不要为电子邮件、微信三方或 Telegram 分别创建重复的发送日志页面。

`pushLog` 是后台“发送日志”的唯一数据源。渠道尚未具备发送能力时，只保存配置，不得生成伪造的成功或失败记录。

## 7. 新功能完成前检查

验证强度必须与改动范围和风险匹配，禁止每次小改动都机械执行完整生产构建：

- 纯前端展示、Tailwind class、文案或局部交互调整：运行修改文件的 diagnostics；必要时通过开发服务器和目标页面手动确认。默认不运行 `bun run build`、全量 lint 或全量测试。
- 单个组件或页面的 TypeScript/Vue 逻辑调整：运行修改文件的 diagnostics，并运行该功能已有的针对性测试（如果有）。只有涉及 SSR、路由、构建配置或跨模块契约时才补充 `bun run build`。
- 服务端、数据库 schema、迁移、依赖、路由或公共类型调整：运行相关 diagnostics 和针对性测试；改动可能影响生产产物时再运行 `bun run build`。
- 发布前、构建配置修改、依赖升级、跨页面 SSR 改动或用户明确要求时，必须运行 `bun run build`。
- 本节命令统一使用项目实际脚本 `bun run ...`，不要擅自替换成 `npm run ...`。

提交前至少完成：

1. 对修改的 `.vue` / `.ts` 文件运行 diagnostics。
2. 按上述改动分级执行针对性测试、lint 或 build；不能新增 warning 或 error。
3. 新增或调整后台页时，确认 `adminPages` 的 `title`、`path`、`pageTitle`、`description` 完整，且页面通过 `AdminPageHeader` 或模块布局读取它们。
5. 手动验证至少一个成功路径、一个输入错误路径和一个破坏性操作确认路径。
6. 运行相关 `tests/**/*.test.ts`：管理授权必须覆盖 guest / user / root，前端错误必须验证未知原始错误不透出，数据库日志必须验证 `sign` 与密钥不入库；未预期异常的测试应验证完整请求与堆栈会交给 Observability 输出。
7. 检查列表响应和前端错误未泄露敏感字段、原始异常或密钥；数据库日志已移除 `sign` 与密钥；部署后在 Workers Observability 查询完整接口信息，并确认筛选、分页、空状态和 Toast 行为符合本规范。
