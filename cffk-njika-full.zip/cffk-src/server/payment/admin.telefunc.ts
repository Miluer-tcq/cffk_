import { telefuncAction } from "@/server/telefunc-action";
import { asc, count, eq } from "drizzle-orm";

import { requireAdmin } from "@/server/telefunc-context";
import { paymentLog, paymentProvider, siteSetting } from "@/database/drizzle/schema";
import { appError } from "@/lib/app-error";
import { mergeJsonFormValues, redactJsonFormValues, type JsonFormSubmitValues, type JsonFormValues } from "@/lib/json-form-values";
import { getPaymentUrlDefaults, getPaymentUrlPaths, getProviderDefinition, paymentProviderDefinitions, parseProviderConfig, type PaymentProviderKind } from "./registry";
import { paymentRepository } from "./repository";


function now() {
  return new Date();
}

export function rebasePaymentUrl(value: unknown, fallback: string, siteUrl: string | null) {
  if (!siteUrl || typeof value !== "string" || !value.trim()) return fallback;
  try {
    const currentOrigin = new URL(siteUrl).origin;
    const url = new URL(value, `${currentOrigin}/`);
    return `${currentOrigin}${url.pathname}${url.search}${url.hash}`;
  } catch {
    return fallback;
  }
}

export function mergePaymentUrls(provider: PaymentProviderKind, siteUrl: string | null | undefined, values: Record<string, unknown>): Record<string, string> {
  const defaults = getPaymentUrlDefaults(provider, siteUrl);
  const paths = getPaymentUrlPaths(provider);
  const hasNotifyUrl = getProviderDefinition(provider)?.fields.some((field) => field.key === "notifyUrl") ?? false;
  if (!defaults.returnUrl || (hasNotifyUrl && !defaults.notifyUrl)) appError("PAYMENT_SITE_URL_REQUIRED");
  const origin = new URL(siteUrl!).origin;
  const rawReturnUrl = typeof values.returnUrl === "string" && values.returnUrl.trim() ? values.returnUrl.trim() : defaults.returnUrl;
  let parsedReturnUrl: URL;
  try { parsedReturnUrl = new URL(rawReturnUrl, `${origin}/`); } catch { appError("PAYMENT_RETURN_URL_INVALID"); }
  if (parsedReturnUrl.origin !== origin || parsedReturnUrl.username || parsedReturnUrl.password || !parsedReturnUrl.pathname.startsWith("/")) appError("PAYMENT_RETURN_URL_INVALID");
  if (hasNotifyUrl) {
    const rawNotifyUrl = typeof values.notifyUrl === "string" && values.notifyUrl.trim() ? values.notifyUrl.trim() : defaults.notifyUrl;
    let parsedNotifyUrl: URL;
    try { parsedNotifyUrl = new URL(rawNotifyUrl, `${origin}/`); } catch { appError("PAYMENT_NOTIFY_URL_INVALID"); }
    if (parsedNotifyUrl.origin !== origin || parsedNotifyUrl.username || parsedNotifyUrl.password || parsedNotifyUrl.pathname !== paths.notifyUrl || parsedNotifyUrl.search || parsedNotifyUrl.hash) appError("PAYMENT_NOTIFY_URL_INVALID");
  }
  const result: Record<string, string> = { returnUrl: `${parsedReturnUrl.pathname}${parsedReturnUrl.search}${parsedReturnUrl.hash}` };
  if (hasNotifyUrl) result.notifyUrl = paths.notifyUrl;
  return result;
}


export function mergePaymentProviderConfig(input: {
  provider: PaymentProviderKind;
  currentConfigJson?: string;
  values: JsonFormSubmitValues;
}) {
  const definition = getProviderDefinition(input.provider);
  if (!definition) appError("PAYMENT_PROVIDER_NOT_IMPLEMENTED");
  let existing: Record<string, unknown> = {};
  if (input.currentConfigJson) {
    try {
      const parsed: unknown = JSON.parse(input.currentConfigJson);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) existing = parsed as Record<string, unknown>;
    } catch { /* Invalid stored JSON cannot block a complete replacement. */ }
  }
  let config: Record<string, unknown>;
  try { config = mergeJsonFormValues(definition.fields, input.values ?? {}, existing); } catch { appError("PAYMENT_CONFIG_INVALID"); }
  config.schemaVersion = definition.schemaVersion;
  const configJson = JSON.stringify(config);
  try { parseProviderConfig(input.provider, configJson); } catch { appError("PAYMENT_CONFIG_INVALID"); }
  return configJson;
}

function getSafeForm(provider: string, name: string, isEnabled: boolean, sort: number, configJson: string, siteUrl: string | null, updatedAt?: Date) {
  const definition = getProviderDefinition(provider);
  if (!definition) return null;
  let parsed: Record<string, unknown> = {};
  try {
    const raw: unknown = JSON.parse(configJson);
    if (raw && typeof raw === "object" && !Array.isArray(raw)) parsed = raw as Record<string, unknown>;
  } catch { /* Syntax-damaged JSON has no recoverable fields. */ }
  let valid = true;
  try { parseProviderConfig(provider, configJson); } catch { valid = false; }

  const urlDefaults = getPaymentUrlDefaults(provider as PaymentProviderKind, siteUrl);
  const displayValues = {
    ...definition.defaults,
    ...parsed,
    notifyUrl: urlDefaults.notifyUrl,
    returnUrl: rebasePaymentUrl(parsed.returnUrl, urlDefaults.returnUrl, siteUrl),
  };
  const { values, configuredSecrets } = redactJsonFormValues(definition.fields, displayValues);
  return { provider, title: definition.title, name, isEnabled, sort, updatedAt: updatedAt?.toISOString() ?? null, valid, schemaVersion: definition.schemaVersion, fields: definition.fields, values: values as JsonFormValues, configuredSecrets, siteUrl };
}

async function internalOnGetPaymentProviders() {
  const { db } = requireAdmin();
  const [settings] = await db.select({ siteUrl: siteSetting.siteUrl }).from(siteSetting).where(eq(siteSetting.id, 1)).limit(1);
  const records = await db.select().from(paymentProvider).orderBy(asc(paymentProvider.sort), asc(paymentProvider.id));
  const byProvider = new Map(records.map((record) => [record.provider, record]));
  return (Object.keys(paymentProviderDefinitions) as PaymentProviderKind[]).map((provider, index) => {
    const record = byProvider.get(provider);
    return getSafeForm(provider, record?.name ?? paymentProviderDefinitions[provider].title, record?.isEnabled ?? false, record?.sort ?? (index + 1) * 10, record?.configJson ?? JSON.stringify(paymentProviderDefinitions[provider].defaults), settings?.siteUrl ?? null, record?.updatedAt)!;
  });
}

async function internalOnGetPaymentProviderForm(input: { provider: PaymentProviderKind }) {
  const { db } = requireAdmin();
  const [settings] = await db.select({ siteUrl: siteSetting.siteUrl }).from(siteSetting).where(eq(siteSetting.id, 1)).limit(1);
  const [record] = await db.select().from(paymentProvider).where(eq(paymentProvider.provider, input.provider)).limit(1);
  return getSafeForm(input.provider, record?.name ?? paymentProviderDefinitions[input.provider].title, record?.isEnabled ?? false, record?.sort ?? 0, record?.configJson ?? JSON.stringify(paymentProviderDefinitions[input.provider].defaults), settings?.siteUrl ?? null, record?.updatedAt);
}

async function savePaymentProvider(input: {
  provider: PaymentProviderKind;
  name: string;
  isEnabled: boolean;
  values: JsonFormSubmitValues;
}) {
  const { db } = requireAdmin();
  const definition = getProviderDefinition(input.provider);
  if (!definition) appError("PAYMENT_PROVIDER_NOT_IMPLEMENTED");
  const name = input.name.trim();
  if (!name) appError("PAYMENT_PROVIDER_NAME_REQUIRED");
  const [current, settings] = await Promise.all([
    db.select().from(paymentProvider).where(eq(paymentProvider.provider, input.provider)).limit(1).then(([record]) => record),
    db.select({ siteUrl: siteSetting.siteUrl }).from(siteSetting).where(eq(siteSetting.id, 1)).limit(1).then(([record]) => record),
  ]);
  const urls = mergePaymentUrls(input.provider, settings?.siteUrl, input.values);
  const configJson = mergePaymentProviderConfig({ provider: input.provider, currentConfigJson: current?.configJson, values: { ...input.values, ...urls } });
  const timestamp = now();
  if (current) {
    await db.update(paymentProvider).set({ name, isEnabled: input.isEnabled, configJson, updatedAt: timestamp }).where(eq(paymentProvider.provider, input.provider));
  } else {
    await db.insert(paymentProvider).values({ provider: input.provider, name, isEnabled: input.isEnabled, sort: 0, configJson, createdAt: timestamp, updatedAt: timestamp });
  }
  return { provider: input.provider };
}

async function internalOnGetPaymentLogs(input?: { provider?: PaymentProviderKind; page?: number; pageSize?: number }) {
  const { database, db } = requireAdmin();
  const page = Math.max(1, Math.floor(input?.page ?? 1));
  const pageSize = Math.min(100, Math.max(10, Math.floor(input?.pageSize ?? 20)));
  const provider = input?.provider;
  const rows = await paymentRepository(database).listLogs({ provider, page, pageSize });
  const where = provider ? eq(paymentLog.provider, provider) : undefined;
  const [total] = await db.select({ value: count() }).from(paymentLog).where(where);
  return { rows, total: total?.value ?? 0, page, pageSize };
}

async function clearPaymentLogs() {
  const { db } = requireAdmin();
  await db.delete(paymentLog);
}

async function validatePaymentProviderConfig(input: {
  provider: PaymentProviderKind;
  values: JsonFormSubmitValues;
}) {
  const { db } = requireAdmin();
  const [record, settings] = await Promise.all([
    db.select().from(paymentProvider).where(eq(paymentProvider.provider, input.provider)).limit(1).then(([item]) => item),
    db.select({ siteUrl: siteSetting.siteUrl }).from(siteSetting).where(eq(siteSetting.id, 1)).limit(1).then(([item]) => item),
  ]);
  if (!record) appError("PAYMENT_PROVIDER_NOT_FOUND");
  const urls = mergePaymentUrls(input.provider, settings?.siteUrl, input.values);
  mergePaymentProviderConfig({ provider: input.provider, currentConfigJson: record.configJson, values: { ...input.values, ...urls } });
  return { provider: input.provider, valid: true };
}

async function setPaymentProviderEnabled(input: { provider: PaymentProviderKind; isEnabled: boolean }) {
  const { db } = requireAdmin();
  const [record] = await db.select().from(paymentProvider).where(eq(paymentProvider.provider, input.provider)).limit(1);
  if (!record) appError("PAYMENT_PROVIDER_NOT_FOUND");
  if (input.isEnabled) {
    try { parseProviderConfig(input.provider, record.configJson); } catch { appError("PAYMENT_CONFIG_INVALID"); }
  }
  await db.update(paymentProvider).set({ isEnabled: input.isEnabled, updatedAt: now() }).where(eq(paymentProvider.provider, input.provider));
  return { provider: input.provider, isEnabled: input.isEnabled };
}

export const onGetPaymentProviders = telefuncAction(internalOnGetPaymentProviders);
export const onGetPaymentProviderForm = telefuncAction(internalOnGetPaymentProviderForm);
export const onSavePaymentProvider = telefuncAction(savePaymentProvider);
export const onGetPaymentLogs = telefuncAction(internalOnGetPaymentLogs);
export const onClearPaymentLogs = telefuncAction(clearPaymentLogs);
export const onValidatePaymentProviderConfig = telefuncAction(validatePaymentProviderConfig);
export const onSetPaymentProviderEnabled = telefuncAction(setPaymentProviderEnabled);
